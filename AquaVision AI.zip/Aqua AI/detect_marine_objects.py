#!/usr/bin/env python3
"""
Underwater Marine Object Detection - Inference Script
For use with Flask application
"""

import torch
from ultralytics import YOLO
from pathlib import Path
import cv2
import numpy as np
from typing import List, Dict, Tuple
import time

class MarineDetector:
    """Marine object detector wrapper for easy inference"""

    def __init__(self, model_path='runs/train/marine_detector/weights/best.pt'):
        """
        Initialize the marine detector

        Args:
            model_path: Path to trained model weights
        """
        self.model_path = Path(model_path)

        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Model weights not found at {model_path}. "
                f"Please train the model first using train_marine_detector.py"
            )

        # Check MPS availability
        self.device = 'mps' if torch.backends.mps.is_available() else 'cpu'
        print(f"Loading model on {self.device}...")

        # Load model
        self.model = YOLO(str(self.model_path))

        # Class names
        self.class_names = {
            0: 'fish',
            1: 'small_fish',
            2: 'crab',
            3: 'shrimp',
            4: 'jellyfish',
            5: 'starfish'
        }

        print(f"✓ Model loaded successfully!")
        print(f"Classes: {', '.join(self.class_names.values())}")

    def detect(self, image_path: str, conf_threshold: float = 0.5,
               iou_threshold: float = 0.6) -> List[Dict]:
        """
        Detect marine objects in an image

        Args:
            image_path: Path to input image
            conf_threshold: Confidence threshold for detections
            iou_threshold: IoU threshold for NMS

        Returns:
            List of detections with format:
            [{'class': 'fish', 'confidence': 0.95, 'bbox': [x1, y1, x2, y2]}, ...]
        """
        start_time = time.time()

        # Run inference
        results = self.model.predict(
            image_path,
            conf=conf_threshold,
            iou=iou_threshold,
            device=self.device,
            verbose=False
        )

        inference_time = (time.time() - start_time) * 1000  # Convert to ms

        # Parse results
        detections = []
        if len(results) > 0 and results[0].boxes is not None:
            boxes = results[0].boxes

            for i in range(len(boxes)):
                box = boxes[i]
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                bbox = box.xyxy[0].cpu().numpy().tolist()  # [x1, y1, x2, y2]

                detections.append({
                    'class': self.class_names[cls_id],
                    'class_id': cls_id,
                    'confidence': round(conf, 3),
                    'bbox': [round(x, 2) for x in bbox],
                })

        return detections, inference_time

    def detect_and_visualize(self, image_path: str, output_path: str = None,
                            conf_threshold: float = 0.25,
                            iou_threshold: float = 0.45) -> Tuple[List[Dict], str]:
        """
        Detect and visualize marine objects

        Args:
            image_path: Path to input image
            output_path: Path to save annotated image (if None, auto-generated)
            conf_threshold: Confidence threshold
            iou_threshold: IoU threshold

        Returns:
            Tuple of (detections, output_image_path)
        """
        # Get detections
        detections, inference_time = self.detect(image_path, conf_threshold, iou_threshold)

        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")

        # Draw detections
        for det in detections:
            x1, y1, x2, y2 = [int(x) for x in det['bbox']]
            cls = det['class']
            conf = det['confidence']

            # Color mapping for different classes
            colors = {
                'fish': (0, 255, 0),        # Green
                'small_fish': (0, 255, 255), # Yellow
                'crab': (255, 0, 0),        # Blue
                'shrimp': (255, 0, 255),    # Magenta
                'jellyfish': (255, 255, 0), # Cyan
                'starfish': (0, 165, 255),  # Orange
            }
            color = colors.get(cls, (255, 255, 255))

            # Draw bounding box
            cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)

            # Draw label background
            label = f"{cls} {conf:.2f}"
            (label_w, label_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
            cv2.rectangle(image, (x1, y1 - label_h - 10), (x1 + label_w, y1), color, -1)

            # Draw label text
            cv2.putText(image, label, (x1, y1 - 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)

        # Add inference time
        cv2.putText(image, f"Inference: {inference_time:.1f}ms",
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Save annotated image
        if output_path is None:
            input_path = Path(image_path)
            output_path = input_path.parent / f"{input_path.stem}_detected{input_path.suffix}"

        cv2.imwrite(str(output_path), image)

        return detections, str(output_path), inference_time

    def detect_batch(self, image_paths: List[str], conf_threshold: float = 0.25) -> List[List[Dict]]:
        """
        Detect marine objects in multiple images

        Args:
            image_paths: List of image paths
            conf_threshold: Confidence threshold

        Returns:
            List of detection lists (one per image)
        """
        all_detections = []
        for img_path in image_paths:
            detections, _ = self.detect(img_path, conf_threshold)
            all_detections.append(detections)

        return all_detections

    def get_model_info(self) -> Dict:
        """Get model information"""
        return {
            'model_path': str(self.model_path),
            'device': self.device,
            'classes': self.class_names,
            'num_classes': len(self.class_names)
        }


def main():
    """Demo usage of the detector"""
    import argparse

    parser = argparse.ArgumentParser(description='Detect marine objects in images')
    parser.add_argument('image', type=str, help='Path to input image')
    parser.add_argument('--model', type=str,
                       default='runs/train/marine_detector/weights/best.pt',
                       help='Path to model weights')
    parser.add_argument('--conf', type=float, default=0.25,
                       help='Confidence threshold')
    parser.add_argument('--iou', type=float, default=0.45,
                       help='IoU threshold for NMS')
    parser.add_argument('--output', type=str, default=None,
                       help='Output path for annotated image')
    parser.add_argument('--no-save', action='store_true',
                       help='Do not save annotated image')

    args = parser.parse_args()

    # Initialize detector
    print(f"\n🐠 Underwater Marine Object Detector")
    print("="*60)
    detector = MarineDetector(args.model)

    # Run detection
    print(f"\nProcessing: {args.image}")
    print("-"*60)

    if args.no_save:
        detections, inference_time = detector.detect(args.image, args.conf, args.iou)
        print(f"\n✓ Detection complete! ({inference_time:.1f}ms)")
        print(f"\nFound {len(detections)} objects:")

        for i, det in enumerate(detections, 1):
            print(f"  {i}. {det['class']:12s} - Confidence: {det['confidence']:.3f}")

    else:
        detections, output_path, inference_time = detector.detect_and_visualize(
            args.image, args.output, args.conf, args.iou
        )

        print(f"\n✓ Detection complete! ({inference_time:.1f}ms)")
        print(f"\nFound {len(detections)} objects:")

        for i, det in enumerate(detections, 1):
            print(f"  {i}. {det['class']:12s} - Confidence: {det['confidence']:.3f}")

        print(f"\n📁 Annotated image saved to: {output_path}")

    print("\n" + "="*60 + "\n")


if __name__ == "__main__":
    main()
