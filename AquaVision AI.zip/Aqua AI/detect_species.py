#!/usr/bin/env python3
"""
Marine Species Detection Script - Upload image and detect species
"""
import sys
from pathlib import Path
from ultralytics import YOLO
import cv2

# Species names
SPECIES_NAMES = {
    0: 'Fish',
    1: 'Small Fish',
    2: 'Crab',
    3: 'Shrimp',
    4: 'Jellyfish',
    5: 'Starfish'
}

def detect_species(image_path, model_path=None):
    """
    Detect marine species in an image

    Args:
        image_path: Path to image file
        model_path: Path to trained model
    """

    # Auto-detect model if not specified
    if model_path is None:
        # Try fast model first, then final model
        possible_paths = [
            'runs/train/marine_fast/weights/best.pt',
            'runs/train/marine_final/weights/best.pt',
        ]
        for path in possible_paths:
            if Path(path).exists():
                model_path = path
                break

        if model_path is None:
            print("❌ No trained model found!")
            print("💡 Please train the model first:")
            print("   python train_fast.py  (1-2 hours, recommended)")
            print("   python train_final.py (20 hours, better accuracy)")
            return

    # Check if model exists
    model_file = Path(model_path)
    if not model_file.exists():
        print(f"❌ Model not found at: {model_path}")
        print("💡 Please train the model first by running: python train_fast.py")
        return

    # Check if image exists
    image_file = Path(image_path)
    if not image_file.exists():
        print(f"❌ Image not found at: {image_path}")
        return

    print("\n" + "=" * 70)
    print("🐠 Marine Species Detector")
    print("=" * 70)
    print(f"📷 Image: {image_path}")
    print(f"🤖 Model: {model_path}")
    print("=" * 70)

    # Load model
    print("\n🔄 Loading model...")
    model = YOLO(model_path)

    # Run detection
    print("🔍 Detecting species...")
    results = model.predict(
        source=image_path,
        conf=0.5,   # Confidence threshold (increased to reduce false positives)
        iou=0.6,    # IoU threshold for NMS (stricter filtering)
        max_det=10, # Limit maximum detections
        save=True,  # Save annotated image
        project='runs/detect',
        name='results',
        exist_ok=True
    )

    # Process results
    print("\n" + "=" * 70)
    print("📊 DETECTION RESULTS")
    print("=" * 70)

    result = results[0]
    boxes = result.boxes

    if len(boxes) == 0:
        print("❌ No marine species detected in the image")
    else:
        # Count species
        species_count = {}
        for box in boxes:
            cls_id = int(box.cls[0])
            species_name = SPECIES_NAMES.get(cls_id, f"Unknown_{cls_id}")
            species_count[species_name] = species_count.get(species_name, 0) + 1

        print(f"✅ Found {len(boxes)} marine species:")
        print()
        for species, count in sorted(species_count.items()):
            print(f"  • {species}: {count}")

        print("\n" + "=" * 70)
        print(f"📁 Annotated image saved to: runs/detect/results/")
        print("=" * 70)

    return results

def main():
    if len(sys.argv) < 2:
        print("\n" + "=" * 70)
        print("🐠 Marine Species Detector - Usage")
        print("=" * 70)
        print("\nUsage:")
        print("  python detect_species.py <image_path>")
        print("\nExample:")
        print("  python detect_species.py my_fish_photo.jpg")
        print("\nOr with custom model:")
        print("  python detect_species.py my_fish_photo.jpg path/to/model.pt")
        print("=" * 70)
        return

    image_path = sys.argv[1]

    # Optional: custom model path
    if len(sys.argv) >= 3:
        model_path = sys.argv[2]
    else:
        model_path = None  # Auto-detect

    detect_species(image_path, model_path)

if __name__ == "__main__":
    main()
