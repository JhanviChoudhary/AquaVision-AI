#!/usr/bin/env python3
"""
Fast frame extraction optimized for Mac M4 Pro
Extracts frames from videos and organizes them for YOLO training
"""
import os
import subprocess
from pathlib import Path
from tqdm import tqdm
import multiprocessing as mp

def extract_video_frames(video_path, output_dir):
    """Extract frames from a single video using ffmpeg"""
    video_name = Path(video_path).stem
    output_pattern = os.path.join(output_dir, f"{video_name}-%04d.png")

    # Use ffmpeg with hardware acceleration if available
    cmd = [
        "ffmpeg", "-i", video_path,
        "-vf", "scale=960:540",  # Resize to standard size
        "-sws_flags", "bicubic",
        "-q:v", "2",  # High quality
        output_pattern,
        "-hide_banner", "-loglevel", "error"
    ]

    try:
        subprocess.run(cmd, check=True, capture_output=True)
        return f"Extracted: {video_name}"
    except subprocess.CalledProcessError as e:
        return f"Error with {video_name}: {e}"

def main():
    # Setup directories
    base_dir = Path(__file__).parent
    videos_dir = base_dir / "dataset" / "videos"
    images_dir = base_dir / "images"
    images_dir.mkdir(exist_ok=True)

    # Find all video files
    video_files = []
    for category_dir in videos_dir.iterdir():
        if category_dir.is_dir():
            video_files.extend(list(category_dir.glob("*.avi")))

    print(f"Found {len(video_files)} videos to process")
    print(f"Output directory: {images_dir}")
    print("Starting extraction (this may take 10-15 minutes)...")

    # Process videos with progress bar
    for video_file in tqdm(video_files, desc="Extracting frames"):
        result = extract_video_frames(str(video_file), str(images_dir))

    print(f"\n✓ Frame extraction complete!")
    print(f"Total frames extracted: {len(list(images_dir.glob('*.png')))}")

if __name__ == "__main__":
    main()
