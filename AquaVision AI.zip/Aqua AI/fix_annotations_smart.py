#!/usr/bin/env python3
"""
Smart Annotation Fixer - Keeps multiple objects, fixes only real issues
"""
import os
from pathlib import Path
import shutil

def fix_annotations_smart(labels_dir):
    """Fix only REAL issues: invalid coords, malformed data, exact duplicates"""
    labels_path = Path(labels_dir)

    stats = {
        'total_files': 0,
        'exact_duplicates_removed': 0,
        'invalid_boxes_fixed': 0,
        'empty_files_removed': 0,
        'files_fixed': 0,
        'total_annotations_before': 0,
        'total_annotations_after': 0
    }

    print("🔧 Smart fixing annotations (keeping multiple objects per image)...")

    for label_file in labels_path.glob('*.txt'):
        stats['total_files'] += 1

        try:
            with open(label_file, 'r') as f:
                lines = f.readlines()

            stats['total_annotations_before'] += len(lines)

            # Skip empty files
            if not lines:
                label_file.unlink()
                stats['empty_files_removed'] += 1
                continue

            # Process annotations
            seen = set()
            valid_lines = []
            file_modified = False

            for line in lines:
                line = line.strip()
                if not line:
                    continue

                parts = line.split()

                # Must have exactly 5 values: class_id x_center y_center width height
                if len(parts) != 5:
                    file_modified = True
                    stats['invalid_boxes_fixed'] += 1
                    continue

                try:
                    class_id = int(parts[0])
                    x_center = float(parts[1])
                    y_center = float(parts[2])
                    width = float(parts[3])
                    height = float(parts[4])

                    # Validate class_id (0-5 for 6 classes)
                    if class_id < 0 or class_id > 5:
                        file_modified = True
                        stats['invalid_boxes_fixed'] += 1
                        continue

                    # Fix coordinates if slightly out of bounds (common annotation error)
                    x_center = max(0.0, min(1.0, x_center))
                    y_center = max(0.0, min(1.0, y_center))
                    width = max(0.001, min(1.0, width))
                    height = max(0.001, min(1.0, height))

                    # Make sure box doesn't go out of image bounds
                    if x_center - width/2 < 0:
                        width = x_center * 2
                        file_modified = True
                    if x_center + width/2 > 1:
                        width = (1 - x_center) * 2
                        file_modified = True
                    if y_center - height/2 < 0:
                        height = y_center * 2
                        file_modified = True
                    if y_center + height/2 > 1:
                        height = (1 - y_center) * 2
                        file_modified = True

                    # Check for EXACT duplicates only (same box in same location)
                    annotation_key = f"{class_id}_{x_center:.6f}_{y_center:.6f}_{width:.6f}_{height:.6f}"
                    if annotation_key in seen:
                        file_modified = True
                        stats['exact_duplicates_removed'] += 1
                        continue

                    seen.add(annotation_key)
                    valid_lines.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}\n")

                except (ValueError, IndexError):
                    file_modified = True
                    stats['invalid_boxes_fixed'] += 1
                    continue

            stats['total_annotations_after'] += len(valid_lines)

            # Write back if modified or if we need to clean up formatting
            if file_modified or len(valid_lines) != len(lines):
                if valid_lines:
                    with open(label_file, 'w') as f:
                        f.writelines(valid_lines)
                    stats['files_fixed'] += 1
                else:
                    # No valid annotations left, remove the file
                    label_file.unlink()
                    stats['empty_files_removed'] += 1

        except Exception as e:
            print(f"❌ Error processing {label_file.name}: {e}")
            continue

    return stats

def main():
    labels_dir = "/Users/yashmittal/Downloads/archive (3)/labels"

    print("=" * 70)
    print("🔧 SMART ANNOTATION FIXER")
    print("=" * 70)
    print("✓ Keeps multiple objects per image (groups of fish, etc.)")
    print("✓ Fixes only REAL issues: invalid coords, malformed data")
    print("✓ Removes only EXACT duplicates (same box twice)")
    print("=" * 70)

    # Backup original labels
    backup_dir = Path(labels_dir).parent / "labels_backup"
    if not backup_dir.exists():
        print(f"\n📦 Creating backup at: {backup_dir}")
        shutil.copytree(labels_dir, backup_dir)
        print("✅ Backup created successfully!")
    else:
        print(f"\n📦 Backup already exists at: {backup_dir}")

    # Fix annotations
    print(f"\n🔧 Processing labels in: {labels_dir}")
    stats = fix_annotations_smart(labels_dir)

    # Print results
    print("\n" + "=" * 70)
    print("📊 RESULTS")
    print("=" * 70)
    print(f"Total files processed:           {stats['total_files']}")
    print(f"Files fixed:                     {stats['files_fixed']}")
    print(f"Total annotations before:        {stats['total_annotations_before']}")
    print(f"Total annotations after:         {stats['total_annotations_after']}")
    print(f"Exact duplicates removed:        {stats['exact_duplicates_removed']}")
    print(f"Invalid boxes fixed:             {stats['invalid_boxes_fixed']}")
    print(f"Empty files removed:             {stats['empty_files_removed']}")
    print("=" * 70)
    print("✅ DATASET READY FOR TRAINING!")
    print("=" * 70)

if __name__ == "__main__":
    main()
