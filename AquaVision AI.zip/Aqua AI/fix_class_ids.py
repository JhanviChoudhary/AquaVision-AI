#!/usr/bin/env python3
"""
Fix class IDs: Convert from 1-6 to 0-5 (YOLO format)
"""

from pathlib import Path

def fix_class_ids():
    base_dir = Path(__file__).parent
    labels_dir = base_dir / "labels"

    print("Fixing class IDs (converting 1-6 to 0-5)...")

    label_files = list(labels_dir.glob("*.txt"))
    total = len(label_files)
    fixed = 0

    for i, label_file in enumerate(label_files):
        if i % 1000 == 0:
            print(f"Processing {i}/{total}...")

        with open(label_file, 'r') as f:
            lines = f.readlines()

        fixed_lines = []
        has_changes = False

        for line in lines:
            parts = line.strip().split()
            if len(parts) < 5:
                continue

            class_id = int(parts[0])
            coords = ' '.join(parts[1:5])

            # Convert 1-6 to 0-5
            if class_id >= 1 and class_id <= 6:
                class_id = class_id - 1
                has_changes = True
            elif class_id > 6:
                # Skip invalid classes
                continue

            fixed_lines.append(f"{class_id} {coords}\n")

        if has_changes and fixed_lines:
            with open(label_file, 'w') as f:
                f.writelines(fixed_lines)
            fixed += 1

    print(f"\n✓ Class ID fix complete!")
    print(f"  Total files: {total}")
    print(f"  Fixed: {fixed}")

if __name__ == "__main__":
    fix_class_ids()
