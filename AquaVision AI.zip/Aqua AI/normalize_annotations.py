#!/usr/bin/env python3
"""
Normalize YOLO annotations from absolute pixel coordinates to 0-1 range
"""

from pathlib import Path
import cv2

def normalize_annotations():
    base_dir = Path(__file__).parent
    images_dir = base_dir / "images"
    labels_dir = base_dir / "labels"

    print("Normalizing annotations to YOLO format (0-1 range)...")

    label_files = list(labels_dir.glob("*.txt"))
    total = len(label_files)
    normalized = 0
    skipped = 0

    for i, label_file in enumerate(label_files):
        if i % 1000 == 0:
            print(f"Processing {i}/{total}...")

        # Find corresponding image
        img_file = images_dir / f"{label_file.stem}.png"

        if not img_file.exists():
            skipped += 1
            continue

        # Read image dimensions
        img = cv2.imread(str(img_file))
        if img is None:
            skipped += 1
            continue

        h, w = img.shape[:2]

        # Read annotations
        with open(label_file, 'r') as f:
            lines = f.readlines()

        # Normalize coordinates
        normalized_lines = []
        has_changes = False

        for line in lines:
            parts = line.strip().split()
            if len(parts) < 5:
                continue

            class_id = parts[0]
            x_center, y_center, width, height = map(float, parts[1:5])

            # Check if already normalized
            if x_center > 1 or y_center > 1 or width > 1 or height > 1:
                # Normalize to 0-1 range
                x_center /= w
                y_center /= h
                width /= w
                height /= h
                has_changes = True

            # Ensure values are within 0-1 range
            x_center = max(0, min(1, x_center))
            y_center = max(0, min(1, y_center))
            width = max(0, min(1, width))
            height = max(0, min(1, height))

            normalized_lines.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}\n")

        # Write back if changes were made
        if has_changes and normalized_lines:
            with open(label_file, 'w') as f:
                f.writelines(normalized_lines)
            normalized += 1

    print(f"\n✓ Normalization complete!")
    print(f"  Total files: {total}")
    print(f"  Normalized: {normalized}")
    print(f"  Skipped: {skipped}")
    print(f"  Already normalized: {total - normalized - skipped}")

if __name__ == "__main__":
    normalize_annotations()
