#!/bin/bash
# Quick Start Script for Marine Detection Model
# Run this after frame extraction is complete

echo "🐠 Underwater Marine Detection - Quick Start"
echo "=============================================="
echo ""

# Check if images directory exists
if [ ! -d "images" ]; then
    echo "❌ Images directory not found!"
    echo "Please run: python3 extract_frames_fast.py first"
    exit 1
fi

# Count images
image_count=$(ls images/*.png 2>/dev/null | wc -l)
echo "✓ Found $image_count images"
echo ""

# Step 1: Verify dataset
echo "Step 1: Verifying dataset..."
python3 verify_dataset.py
echo ""

# Step 2: Ask user about training
echo "=============================================="
echo "Step 2: Training Options"
echo "=============================================="
echo ""
echo "Choose training mode:"
echo "  1) Quick test (20 epochs, ~20 minutes)"
echo "  2) Standard (50 epochs, ~45 minutes)"
echo "  3) Full training (100 epochs, ~90 minutes) - RECOMMENDED"
echo "  4) Custom parameters"
echo ""
read -p "Enter choice (1-4): " choice

case $choice in
    1)
        echo "Starting quick test training..."
        python3 train_marine_detector.py --epochs 20 --batch-size 16
        ;;
    2)
        echo "Starting standard training..."
        python3 train_marine_detector.py --epochs 50 --batch-size 16
        ;;
    3)
        echo "Starting full training..."
        python3 train_marine_detector.py --epochs 100 --batch-size 16
        ;;
    4)
        echo "Enter parameters:"
        read -p "Epochs (default 100): " epochs
        read -p "Batch size (default 16): " batch
        read -p "Model size n/s/m/l/x (default n): " model

        epochs=${epochs:-100}
        batch=${batch:-16}
        model=${model:-n}

        python3 train_marine_detector.py --epochs $epochs --batch-size $batch --model $model
        ;;
    *)
        echo "Invalid choice!"
        exit 1
        ;;
esac

echo ""
echo "=============================================="
echo "✓ Training complete!"
echo "=============================================="
echo ""
echo "Next steps:"
echo "  1. Check results in: runs/train/marine_detector/"
echo "  2. Test detection: python3 detect_marine_objects.py test_image.jpg"
echo "  3. Integrate with Flask application"
echo ""
