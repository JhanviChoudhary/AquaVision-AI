#!/bin/sh
python frameExtractor.py -inputFolder ../dataset/crab
python frameExtractor.py -inputFolder ../dataset/fish-big
python frameExtractor.py -inputFolder ../dataset/fish-school
python frameExtractor.py -inputFolder ../dataset/fish-small-shrimp
python frameExtractor.py -inputFolder ../dataset/jellyfish
