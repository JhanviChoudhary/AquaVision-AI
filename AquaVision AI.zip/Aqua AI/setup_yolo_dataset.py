#!/usr/bin/env python3
"""
Setup YOLO dataset structure properly
Updates paths in train/valid/test.txt to match YOLO format
"""

from pathlib import Path
import os

base_dir = Path(__file__).parent
images_dir = base_dir / "images"
labels_dir = base_dir / "labels"

print("Setting up YOLO dataset structure...")
print(f"Images directory: {images_dir}")
print(f"Labels directory: {labels_dir}")

# Verify directories exist
if not images_dir.exists():
    print(f"❌ Error: Images directory not found!")
    exit(1)

if not labels_dir.exists():
    print(f"❌ Error: Labels directory not found!")
    exit(1)

# Count files
image_files = set(f.stem for f in images_dir.glob("*.png"))
label_files = set(f.stem for f in labels_dir.glob("*.txt"))

print(f"\n✓ Found {len(image_files)} images")
print(f"✓ Found {len(label_files)} labels")

# Check matching
matching = image_files & label_files
print(f"✓ {len(matching)} images have matching labels")

if len(matching) == 0:
    print("❌ No matching image-label pairs found!")
    exit(1)

# Update train/val/test splits
for split_name in ['train.txt', 'valid.txt', 'test.txt']:
    split_file = base_dir / split_name

    if not split_file.exists():
        print(f"⚠ {split_name} not found, skipping...")
        continue

    # Read original file
    with open(split_file, 'r') as f:
        lines = [l.strip() for l in f.readlines() if l.strip()]

    # Update paths
    updated_lines = []
    matched = 0
    for line in lines:
        # Extract filename without extension
        filename = Path(line).stem

        # Check if image and label exist
        img_path = images_dir / f"{filename}.png"
        lbl_path = labels_dir / f"{filename}.txt"

        if img_path.exists() and lbl_path.exists():
            # Use absolute path
            updated_lines.append(str(img_path) + '\n')
            matched += 1

    # Write updated file
    with open(split_file, 'w') as f:
        f.writelines(updated_lines)

    print(f"✓ Updated {split_name}: {matched}/{len(lines)} images with labels")

print("\n✓ Dataset setup complete!")
print("\nYou can now run training:")
print("python3 train_marine_detector.py --epochs 50 --batch-size 16")
