#!/usr/bin/env python3
"""
FAST Marine Species Detector Training - Optimized for Mac M4 Pro
Trains in ~1-2 hours instead of 20 hours
"""
import os
import torch
from ultralytics import YOLO
from pathlib import Path

def train_fast():
    """Train YOLOv8 with maximum speed optimization for M4 Pro"""

    print("\n" + "=" * 70)
    print("🚀 FAST Marine Species Detector - Mac M4 Pro Optimized")
    print("=" * 70)

    # Check device
    if torch.backends.mps.is_available():
        device = 'mps'
        print("✓ MPS (Metal GPU) - FULL POWER MODE!")
    else:
        device = 'cpu'
        print("✓ Using CPU")

    # FAST Configuration - Optimized for M4 Pro
    config = {
        'model': 'yolov8n.pt',
        'data': '/Users/yashmittal/Downloads/archive (3)/marine_dataset.yaml',
        'epochs': 30,           # Reduced from 100 - still effective
        'imgsz': 416,           # Smaller images = MUCH faster
        'batch': 32,            # Large batch for M4 Pro power
        'device': device,
        'project': 'runs/train',
        'name': 'marine_fast',
        'patience': 15,         # Early stopping
        'save_period': 5,       # Save every 5 epochs
        'optimizer': 'AdamW',
        'verbose': True,
        'exist_ok': True,
        'cache': True,          # Cache images in RAM for speed
        'workers': 8,           # Use all CPU cores
        'amp': True,            # Automatic mixed precision
        'close_mosaic': 5,      # Disable mosaic augmentation earlier
        'mixup': 0.0,           # Disable mixup for speed
        'copy_paste': 0.0,      # Disable copy-paste for speed
    }

    print("\n" + "=" * 70)
    print("⚡ FAST TRAINING CONFIGURATION")
    print("=" * 70)
    print(f"Model: YOLOv8n (fastest)")
    print(f"Device: {device} (M4 Pro)")
    print(f"Epochs: {config['epochs']} (reduced for speed)")
    print(f"Image Size: {config['imgsz']} (smaller = 2x faster)")
    print(f"Batch Size: {config['batch']} (utilizing M4 Pro power)")
    print(f"Workers: {config['workers']} (all CPU cores)")
    print(f"Cache: {config['cache']} (images cached in RAM)")
    print(f"Classes: 6 (fish, small_fish, crab, shrimp, jellyfish, starfish)")
    print("=" * 70)
    print("⏱️  Estimated time: 1-2 hours (vs 20 hours normal)")
    print("=" * 70)

    # Load model
    print("\n🚀 Loading YOLOv8n model...")
    model = YOLO(config['model'])

    # Train
    print("\n🔥 Starting FAST training...")
    print("💡 Using ALL M4 Pro resources!")
    print("💡 Checkpoints saved every 5 epochs")

    try:
        results = model.train(
            data=config['data'],
            epochs=config['epochs'],
            imgsz=config['imgsz'],
            batch=config['batch'],
            device=config['device'],
            project=config['project'],
            name=config['name'],
            patience=config['patience'],
            save_period=config['save_period'],
            optimizer=config['optimizer'],
            verbose=config['verbose'],
            exist_ok=config['exist_ok'],
            cache=config['cache'],
            workers=config['workers'],
            amp=config['amp'],
            close_mosaic=config['close_mosaic'],
            mixup=config['mixup'],
            copy_paste=config['copy_paste'],
        )

        print("\n" + "=" * 70)
        print("✅ FAST TRAINING COMPLETED!")
        print("=" * 70)

        # Model location
        best_model_path = Path(config['project']) / config['name'] / 'weights' / 'best.pt'
        print(f"\n📦 Best model: {best_model_path}")
        print(f"📊 Trained on 8,829 images in ~1-2 hours")

        print("\n🎯 READY TO DETECT!")
        print("Use: python detect_species.py your_image.jpg")

        return True

    except KeyboardInterrupt:
        print("\n\n⚠️  Training interrupted by user")
        print("💾 Last checkpoint saved")
        return False
    except Exception as e:
        print(f"\n\n❌ Training failed: {e}")
        return False

if __name__ == "__main__":
    print("\n🔥 FAST TRAINING MODE ACTIVATED!")
    print("🚀 Utilizing Mac M4 Pro maximum performance")
    print("=" * 70)

    success = train_fast()

    if success:
        print("\n" + "=" * 70)
        print("🎉 YOUR MARINE SPECIES DETECTOR IS READY!")
        print("=" * 70)
        print("\n📝 To detect species in your images:")
        print("   python detect_species.py your_fish_photo.jpg")
        print("\n📁 Model location:")
        print("   runs/train/marine_fast/weights/best.pt")
        print("=" * 70)
