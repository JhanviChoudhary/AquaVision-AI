#!/usr/bin/env python3
"""
Final Marine Species Detector Training Script - Optimized and Stable
"""
import os
import torch
from ultralytics import YOLO
from pathlib import Path

def train_model():
    """Train YOLOv8 model with optimized settings"""

    print("\n" + "=" * 70)
    print("🐠 Marine Species Detector - Final Training")
    print("=" * 70)

    # Check device
    if torch.backends.mps.is_available():
        device = 'mps'
        print("✓ MPS (Metal GPU) is available and will be used for training!")
    else:
        device = 'cpu'
        print("✓ Using CPU for training")

    # Configuration
    config = {
        'model': 'yolov8n.pt',
        'data': '/Users/yashmittal/Downloads/archive (3)/marine_dataset.yaml',
        'epochs': 100,
        'imgsz': 640,
        'batch': 8,  # Reduced batch size for stability
        'device': device,
        'project': 'runs/train',
        'name': 'marine_final',
        'patience': 30,  # Early stopping
        'save_period': 10,  # Save every 10 epochs
        'optimizer': 'AdamW',
        'verbose': True,
        'exist_ok': True,
        'cache': False,  # Don't cache to avoid memory issues
    }

    print("\n" + "=" * 70)
    print("TRAINING CONFIGURATION")
    print("=" * 70)
    print(f"Model: YOLOv8n")
    print(f"Device: {device}")
    print(f"Epochs: {config['epochs']}")
    print(f"Image Size: {config['imgsz']}")
    print(f"Batch Size: {config['batch']}")
    print(f"Classes: 6 (fish, small_fish, crab, shrimp, jellyfish, starfish)")
    print("=" * 70)

    # Load model
    print("\n🚀 Loading YOLOv8n model...")
    model = YOLO(config['model'])

    # Train
    print("\n🚀 Starting training...")
    print("💡 This will take a while. Training will save checkpoints every 10 epochs.")
    print("💡 Press Ctrl+C to stop training (last checkpoint will be saved)")

    try:
        results = model.train(
            data=config['data'],
            epochs=config['epochs'],
            imgsz=config['imgsz'],
            batch=config['batch'],
            device=config['device'],
            project=config['project'],
            name=config['name'],
            patience=config['patience'],
            save_period=config['save_period'],
            optimizer=config['optimizer'],
            verbose=config['verbose'],
            exist_ok=config['exist_ok'],
            cache=config['cache'],
        )

        print("\n" + "=" * 70)
        print("✅ TRAINING COMPLETED SUCCESSFULLY!")
        print("=" * 70)

        # Save final model
        best_model_path = Path(config['project']) / config['name'] / 'weights' / 'best.pt'
        print(f"\n📦 Best model saved at: {best_model_path}")

        return True

    except KeyboardInterrupt:
        print("\n\n⚠️  Training interrupted by user")
        print("💾 Last checkpoint has been saved")
        return False
    except Exception as e:
        print(f"\n\n❌ Training failed with error: {e}")
        print("💾 Checking for saved checkpoints...")
        return False

if __name__ == "__main__":
    success = train_model()

    if success:
        print("\n🎉 Your marine species detector is ready!")
        print("📝 Next: Run the detection script to test it on images")
    else:
        print("\n⚠️  Training incomplete, but checkpoints may be available")
        print("📁 Check: runs/train/marine_final/weights/")
