#!/usr/bin/env python3
"""
Underwater Marine Object Detection Training Script
Optimized for Mac M4 Pro with MPS (Metal Performance Shaders) acceleration
Uses YOLOv8 with transfer learning for fast, accurate training
"""

import os
import torch
from ultralytics import YOLO
from pathlib import Path
import time

def check_mps_available():
    """Check if MPS (Metal Performance Shaders) is available for M4 Pro"""
    if torch.backends.mps.is_available():
        print("✓ MPS (Metal GPU) is available and will be used for training!")
        return True
    else:
        print("⚠ MPS not available, using CPU (training will be slower)")
        return False

def prepare_dataset_paths():
    """Verify dataset paths"""
    base_dir = Path(__file__).parent
    images_dir = base_dir / "images"
    labels_dir = base_dir / "labels"

    print("Verifying dataset paths...")
    print(f"  Images: {images_dir}")
    print(f"  Labels: {labels_dir}")

    # Just verify files exist
    image_count = len(list(images_dir.glob("*.png")))
    label_count = len(list(labels_dir.glob("*.txt")))

    print(f"  ✓ Found {image_count} images")
    print(f"  ✓ Found {label_count} labels")

def train_model(epochs=100, img_size=640, batch_size=16, model_size='n'):
    """
    Train YOLOv8 model on marine dataset

    Args:
        epochs: Number of training epochs (100 recommended)
        img_size: Image size for training (640 is good balance)
        batch_size: Batch size (16 for M4 Pro, adjust if memory issues)
        model_size: YOLOv8 model size - 'n'ano, 's'mall, 'm'edium, 'l'arge, 'x'large
                   'n' is fastest and good for real-time detection
    """

    base_dir = Path(__file__).parent
    config_file = base_dir / "marine_dataset.yaml"

    # Check MPS availability
    mps_available = check_mps_available()
    device = 'mps' if mps_available else 'cpu'

    print(f"\n{'='*60}")
    print(f"TRAINING CONFIGURATION")
    print(f"{'='*60}")
    print(f"Model: YOLOv8{model_size}")
    print(f"Dataset: {config_file}")
    print(f"Device: {device}")
    print(f"Epochs: {epochs}")
    print(f"Image Size: {img_size}")
    print(f"Batch Size: {batch_size}")
    print(f"Classes: 6 (fish, small_fish, crab, shrimp, jellyfish, starfish)")
    print(f"{'='*60}\n")

    # Load pretrained YOLOv8 model (transfer learning)
    print(f"Loading YOLOv8{model_size} pretrained weights...")
    model = YOLO(f'yolov8{model_size}.pt')

    # Prepare dataset
    prepare_dataset_paths()

    print("\n🚀 Starting training...")
    print("Note: First epoch will be slower due to model initialization\n")

    start_time = time.time()

    # Train the model
    results = model.train(
        data=str(config_file),
        epochs=epochs,
        imgsz=img_size,
        batch=batch_size,
        device=device,
        workers=4,  # Data loading workers
        patience=20,  # Early stopping patience
        save=True,
        save_period=10,  # Save checkpoint every 10 epochs
        project='runs/train',
        name='marine_detector',
        exist_ok=True,
        pretrained=True,
        optimizer='AdamW',  # Better optimizer
        lr0=0.001,  # Initial learning rate
        lrf=0.01,  # Final learning rate (lr0 * lrf)
        momentum=0.937,
        weight_decay=0.0005,
        warmup_epochs=3.0,
        warmup_momentum=0.8,
        box=7.5,  # Box loss gain
        cls=0.5,  # Class loss gain
        dfl=1.5,  # DFL loss gain
        hsv_h=0.015,  # HSV-Hue augmentation
        hsv_s=0.7,  # HSV-Saturation augmentation
        hsv_v=0.4,  # HSV-Value augmentation
        degrees=0.0,  # Rotation augmentation (degrees)
        translate=0.1,  # Translation augmentation
        scale=0.5,  # Scale augmentation
        shear=0.0,  # Shear augmentation
        perspective=0.0,  # Perspective augmentation
        flipud=0.0,  # Vertical flip augmentation
        fliplr=0.5,  # Horizontal flip augmentation (50% chance)
        mosaic=1.0,  # Mosaic augmentation
        mixup=0.0,  # Mixup augmentation
        copy_paste=0.0,  # Copy-paste augmentation
        plots=True,  # Generate training plots
        verbose=True
    )

    training_time = time.time() - start_time

    print(f"\n{'='*60}")
    print(f"✓ TRAINING COMPLETE!")
    print(f"{'='*60}")
    print(f"Training time: {training_time/60:.2f} minutes")
    print(f"Best weights saved at: runs/train/marine_detector/weights/best.pt")
    print(f"Last weights saved at: runs/train/marine_detector/weights/last.pt")
    print(f"{'='*60}\n")

    # Validate the model
    print("Running validation on test set...")
    metrics = model.val()

    print(f"\n{'='*60}")
    print(f"VALIDATION METRICS")
    print(f"{'='*60}")
    print(f"mAP50: {metrics.box.map50:.4f}")
    print(f"mAP50-95: {metrics.box.map:.4f}")
    print(f"Precision: {metrics.box.mp:.4f}")
    print(f"Recall: {metrics.box.mr:.4f}")
    print(f"{'='*60}\n")

    return model, results, metrics

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Train Marine Object Detector')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    parser.add_argument('--img-size', type=int, default=640, help='Image size')
    parser.add_argument('--batch-size', type=int, default=16, help='Batch size')
    parser.add_argument('--model', type=str, default='n',
                       choices=['n', 's', 'm', 'l', 'x'],
                       help='Model size: n(ano), s(mall), m(edium), l(arge), x(large)')

    args = parser.parse_args()

    print("\n🐠 Underwater Marine Object Detection - Training Script")
    print("="*60)

    # Train the model
    model, results, metrics = train_model(
        epochs=args.epochs,
        img_size=args.img_size,
        batch_size=args.batch_size,
        model_size=args.model
    )

    print("\n✓ All done! Your model is ready for inference.")
    print("Next step: Use detect_marine_objects.py for predictions\n")
