#!/usr/bin/env python3
"""
Dataset Verification and Analysis Script
Checks dataset integrity and provides statistics
"""

import os
from pathlib import Path
import matplotlib.pyplot as plt
from collections import Counter
import numpy as np

def verify_dataset():
    """Verify dataset structure and provide statistics"""

    base_dir = Path(__file__).parent
    images_dir = base_dir / "images"
    annotations_dir = base_dir / "annotations" / "annotations_YOLO"

    print("\n" + "="*60)
    print("DATASET VERIFICATION & ANALYSIS")
    print("="*60)

    # Check if images exist
    if not images_dir.exists():
        print("\n❌ ERROR: Images directory not found!")
        print("Please run extract_frames_fast.py first to extract frames from videos.")
        return False

    # Count images
    image_files = list(images_dir.glob("*.png"))
    num_images = len(image_files)

    print(f"\n📁 Images Directory: {images_dir}")
    print(f"   Total images: {num_images:,}")

    if num_images == 0:
        print("\n❌ ERROR: No images found! Please extract frames first.")
        return False

    # Check annotations
    annotation_files = list(annotations_dir.glob("*.txt"))
    num_annotations = len(annotation_files)

    print(f"\n📄 Annotations Directory: {annotations_dir}")
    print(f"   Total annotation files: {num_annotations:,}")

    # Analyze class distribution
    print(f"\n📊 Analyzing class distribution...")

    class_names = {
        0: 'fish',
        1: 'small_fish',
        2: 'crab',
        3: 'shrimp',
        4: 'jellyfish',
        5: 'starfish'
    }

    class_counts = Counter()
    total_objects = 0
    images_with_annotations = 0

    for ann_file in annotation_files:
        with open(ann_file, 'r') as f:
            lines = f.readlines()
            if lines:
                images_with_annotations += 1
            for line in lines:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    class_counts[class_id] += 1
                    total_objects += 1

    print(f"\n   Total annotated objects: {total_objects:,}")
    print(f"   Images with annotations: {images_with_annotations:,}")
    print(f"\n   Class Distribution:")
    print(f"   {'-'*50}")

    for class_id in sorted(class_counts.keys()):
        count = class_counts[class_id]
        percentage = (count / total_objects) * 100
        class_name = class_names.get(class_id, f"Unknown_{class_id}")
        bar = "█" * int(percentage / 2)
        print(f"   {class_id}. {class_name:12s}: {count:5,} ({percentage:5.2f}%) {bar}")

    # Check train/val/test splits
    print(f"\n📋 Checking data splits...")

    splits = {
        'train': base_dir / 'train.txt',
        'valid': base_dir / 'valid.txt',
        'test': base_dir / 'test.txt'
    }

    split_counts = {}
    for split_name, split_file in splits.items():
        if split_file.exists():
            with open(split_file, 'r') as f:
                lines = [l.strip() for l in f.readlines() if l.strip()]
                split_counts[split_name] = len(lines)
        else:
            split_counts[split_name] = 0

    print(f"   Train set: {split_counts['train']:,} images")
    print(f"   Valid set: {split_counts['valid']:,} images")
    print(f"   Test set:  {split_counts['test']:,} images")
    print(f"   Total:     {sum(split_counts.values()):,} images")

    # Calculate statistics
    train_pct = (split_counts['train'] / sum(split_counts.values())) * 100
    valid_pct = (split_counts['valid'] / sum(split_counts.values())) * 100
    test_pct = (split_counts['test'] / sum(split_counts.values())) * 100

    print(f"\n   Split percentages:")
    print(f"   Train: {train_pct:.1f}%")
    print(f"   Valid: {valid_pct:.1f}%")
    print(f"   Test:  {test_pct:.1f}%")

    # Recommendations
    print(f"\n💡 RECOMMENDATIONS FOR TRAINING:")
    print(f"   {'-'*50}")

    # Calculate objects per image
    avg_objects_per_image = total_objects / images_with_annotations if images_with_annotations > 0 else 0

    if num_images >= 10000:
        epochs = 100
        batch = 16
        model = 'n'
        print(f"   ✓ Large dataset detected ({num_images:,} images)")
    elif num_images >= 5000:
        epochs = 150
        batch = 16
        model = 'n'
        print(f"   ✓ Medium dataset detected ({num_images:,} images)")
    else:
        epochs = 200
        batch = 8
        model = 'n'
        print(f"   ⚠ Small dataset detected ({num_images:,} images)")
        print(f"     Consider data augmentation")

    print(f"\n   Recommended training parameters:")
    print(f"   • Model size: YOLOv8{model} (nano - fastest)")
    print(f"   • Epochs: {epochs}")
    print(f"   • Batch size: {batch}")
    print(f"   • Image size: 640")
    print(f"   • Device: MPS (Mac M4 Pro GPU)")

    print(f"\n   Average objects per image: {avg_objects_per_image:.2f}")

    if avg_objects_per_image < 1:
        print(f"   ⚠ Low object density - consider reviewing annotations")
    elif avg_objects_per_image < 3:
        print(f"   ✓ Normal object density")
    else:
        print(f"   ✓ High object density - good for detection!")

    # Check for class imbalance
    if class_counts:
        max_count = max(class_counts.values())
        min_count = min(class_counts.values())
        imbalance_ratio = max_count / min_count if min_count > 0 else float('inf')

        print(f"\n   Class imbalance ratio: {imbalance_ratio:.2f}:1")
        if imbalance_ratio > 10:
            print(f"   ⚠ Significant class imbalance detected!")
            print(f"     Consider using weighted loss or data augmentation")
        elif imbalance_ratio > 5:
            print(f"   ⚠ Moderate class imbalance detected")
        else:
            print(f"   ✓ Relatively balanced classes")

    # Estimated training time
    print(f"\n⏱  ESTIMATED TRAINING TIME (M4 Pro):")
    print(f"   {'-'*50}")

    # Rough estimates based on YOLOv8n
    time_per_epoch_minutes = (split_counts['train'] / 1000) * 0.5  # ~0.5 min per 1000 images
    total_time = time_per_epoch_minutes * epochs

    print(f"   Time per epoch: ~{time_per_epoch_minutes:.1f} minutes")
    print(f"   Total time ({epochs} epochs): ~{total_time:.1f} minutes ({total_time/60:.1f} hours)")

    print(f"\n✓ Dataset verification complete!")
    print(f"   You can now run: python3 train_marine_detector.py")
    print("="*60 + "\n")

    return True


if __name__ == "__main__":
    verify_dataset()
